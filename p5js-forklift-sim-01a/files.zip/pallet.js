// pallet.js
// Export a Pallet class that depends on a forklift instance and settings (import or global).

class Pallet {
  constructor(x, z) {
    this.x = x;
    this.z = z;
    this.y = 0;
    this.angle = 0;
    this.w = 85;
    this.h = 18;
    this.d = 80;
    this.isCarried = false;
    this.hasBox = true;
    this.isHome = false;
  }

  attachToForklift(forklift) {
    this.isCarried = true;
    this.carrier = forklift;
  }

  detach() {
    this.isCarried = false;
    this.carrier = null;
  }

  update(forklift, settings) {
    if (this.isCarried && this.carrier) {
      let forkLength = forklift.d / 2 + this.d / 2;
      this.x = forklift.x + sin(forklift.angle) * forkLength;
      this.z = forklift.z + cos(forklift.angle) * forkLength;
      this.y = -forklift.liftY - 5;
      this.angle = forklift.angle;
      this.isHome = false;
    } else {
      this.isHome = (this.z < settings.targetZoneZ + 60 && this.y >= 0);
    }
  }

  display(settings) {
    push();
    translate(this.x, this.y - this.h / 2, this.z);
    rotateY(this.angle);
    if (this.isHome) {
      fill(0, 255, 255);
      stroke(0, 100, 100);
    } else {
      fill(130, 100, 70);
      stroke(60, 40, 20);
    }
    box(this.w, 5, this.d);
    // ... visual details retained
    pop();
  }
}

export default Pallet;