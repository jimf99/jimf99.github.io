import Foundation

struct TodoItem: Codable {
    var id: UUID
    var title: String
    var completed: Bool
}


class TodoList {
    private(set) var items: [TodoItem] = []
    private let dataFile = "todos.json"
    
    init() { load() }
    
    func load() {
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: dataFile)) else { return }
        items = (try? JSONDecoder().decode([TodoItem].self, from: data)) ?? []
    }
    
    func save() {
        guard let data = try? JSONEncoder().encode(items) else { return }
        try? data.write(to: URL(fileURLWithPath: dataFile))
    }
    
    func add(title: String) {
        let item = TodoItem(id: UUID(), title: title, completed: false)
        items.append(item)
        save()
        print("Added.")
    }
    
func list() {
    items.forEach {
        print("\($0.completed ? "[x]" : "[ ]") \($0.title)")
    }
}
    
    func complete(identifier: String) {
        updateItem(identifier: identifier) { $0.completed = true }
    }
    
    func delete(identifier: String) {
        let count = items.count
        items.removeAll { $0.id.uuidString == identifier || $0.title == identifier }
        if items.count < count {
            save()
            print("Deleted.")
        } else {
            print("No todo with that UUID or title.")
        }
    }
    
    func update(identifier: String, newTitle: String) {
        updateItem(identifier: identifier) { $0.title = newTitle }
    }
    
    private func updateItem(identifier: String, update: (inout TodoItem) -> Void) {
        if let idx = findItemIndex(identifier: identifier) {
            update(&items[idx])
            save()
            print("Updated.")
        } else {
            print("No todo with that UUID or title.")
        }
    }
    
    private func findItemIndex(identifier: String) -> Int? {
        if let uuid = UUID(uuidString: identifier) {
            return items.firstIndex(where: { $0.id == uuid })
        }
        return items.firstIndex(where: { $0.title == identifier })
    }
}

func printHelp() {
    print("""
        Todo REPL
        Commands:
          add <title>                Add a todo
          list                       List todos
          complete <uuid|title>      Mark todo as completed
          update <uuid|title> <new>  Update todo title
          delete <uuid|title>        Delete a todo
          help                       Print commands
          quit                       Exit the REPL

          Example: update item1 item1a
        """)
}

let todoList = TodoList()
print("Welcome to Todo REPL! Type 'help' for commands.")

while true {
    print("> ", terminator: "")
    guard let input = readLine() else { continue }
    let args = input.split(separator: " ").map(String.init)
    guard let command = args.first else { continue }
    
    switch command {
    case "add":
        let title = args.dropFirst().joined(separator: " ")
        title.isEmpty ? print("Provide a title.") : todoList.add(title: title)
    case "list":
        todoList.list()
    case "complete":
        args.count > 1 ? todoList.complete(identifier: args[1]) : print("Provide valid identifier.")
    case "delete":
        args.count > 1 ? todoList.delete(identifier: args[1]) : print("Provide valid identifier.")
    case "update":
        if args.count > 2 {
            todoList.update(identifier: args[1], newTitle: args.dropFirst(2).joined(separator: " "))
        } else {
            print("Provide valid identifier and new title.")
        }
    case "help":
        printHelp()
    case "quit":
        print("Goodbye!")
        exit(0)
    default:
        print("Unknown command! Type 'help' for a list of commands.")
    }
}