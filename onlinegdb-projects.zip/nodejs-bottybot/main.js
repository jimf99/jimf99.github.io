#!/usr/bin/env node
/*
server.js - Mini Telnet-style BBS + Local Console
Date: 2025-11-28
Requirements: Node.js 18+
Features:
 - Telnet server (default 0.0.0.0:2323) accepting multiple concurrent clients
 - Local admin console acting as a client
 - Accounts (users.json) with salted SHA-256 password hashes
 - Message boards (boards.json): list/read/post
 - Personal notes (notes.json): add/show/search
 - Reminders (reminders.json): scheduled; deliver when online or queued for next login
 - Utilities: dice roller, math, hash, quote, weather, seen, stardate, time, temp, uptime, opme
 - Persistence in script directory
 - No external dependencies (uses built-in modules only)
 - Config via env: PORT, HOST, OP_PASSWORD, WEATHER_API
*/

const net = require("net");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const readline = require("readline");
const os = require("os");
const http = require("http");
const https = require("https");
const { setTimeout: setT, clearTimeout } = require("timers");

const PORT = Number(process.env.PORT) || 2323;
const HOST = process.env.HOST || "0.0.0.0";
const OP_PASSWORD = process.env.OP_PASSWORD || "change_me";
const WEATHER_API = process.env.WEATHER_API || "https://wttr.in/{loc}?format=%l:+%C+%t+%w+%h";

const DATA_DIR = __dirname;
const USERS_FILE = path.join(DATA_DIR, "users.json");
const BOARDS_FILE = path.join(DATA_DIR, "boards.json");
const NOTES_FILE = path.join(DATA_DIR, "notes.json");
const REMINDERS_FILE = path.join(DATA_DIR, "reminders.json");

const VERSION = "MiniBBS/1.0 (node)";

// In-memory state
const clients = new Set(); // all connected client sessions
const lastSeen = new Map(); // lowerNick -> timestamp (ms)
const users = new Map(); // username -> { salt, hash, createdAt }
const boards = new Map(); // boardName -> [{ id, author, text, ts }]
const notes = new Map(); // username -> { key -> { text, createdAt } }
const reminders = new Map(); // reminderId -> { id, owner, message, at, delivered }

// Local quotes fallback
const localQuotes = [
  "Do or do not. There is no try. — Yoda",
  "Simplicity is the ultimate sophistication. — Leonardo da Vinci",
  "The only limit to our realization of tomorrow is our doubts of today. — F. D. Roosevelt"
];

function nowTs(){ return Date.now(); }
function randInt(min,max){ return Math.floor(Math.random()*(max-min+1))+min; }
function safeReadJson(filePath, fallback){ try{ if(!fs.existsSync(filePath)) return fallback; return JSON.parse(fs.readFileSync(filePath,"utf8")); }catch(e){ return fallback; } }
function safeWriteJson(filePath,obj){ try{ fs.writeFileSync(filePath, JSON.stringify(obj,null,2),"utf8"); return true; }catch(e){ return false; } }
function hashPasswordWithSalt(pass, salt){ return crypto.createHash("sha256").update(salt+pass,"utf8").digest("hex"); }
function genSalt(){ return crypto.randomBytes(8).toString("hex"); }
function toStardate(d = new Date()){ const year = d.getUTCFullYear(); const start = Date.UTC(year,0,1); const dayOfYear = Math.floor((d.getTime()-start)/86400000)+1; const fraction = ((d.getTime()-start)%86400000)/86400000; const stardate = (year - 2323)*1000 + dayOfYear + fraction; return `Stardate ${stardate.toFixed(2)}`; }
function formatSeen(nick, ts){ const d = new Date(ts); return `${nick} was last seen at ${d.toISOString().replace("T"," ").replace("Z"," (UTC)")}`; }
function convertTemp(value, unit){ unit = unit.toLowerCase(); if(unit==="c"||unit==="celsius"){ const f = value*9/5+32; return `${value}°C = ${f.toFixed(1)}°F`; } if(unit==="f"||unit==="fahrenheit"){ const c = (value-32)*5/9; return `${value}°F = ${c.toFixed(1)}°C`; } return "Unknown unit. Use C or F."; }
function utcNowString(offsetHours = 0){ const d = new Date(Date.now() + offsetHours*3600000); return d.toISOString().replace("T"," ").replace("Z", ` (UTC${offsetHours>=0?"+":""}${offsetHours})`); }

// Load persisted state
function loadAll(){
  const u = safeReadJson(USERS_FILE, {});
  for(const k of Object.keys(u)) users.set(k, u[k]);
  const b = safeReadJson(BOARDS_FILE, {});
  for(const k of Object.keys(b)) boards.set(k, b[k]);
  const n = safeReadJson(NOTES_FILE, {});
  for(const user of Object.keys(n)) notes.set(user, n[user]);
  const r = safeReadJson(REMINDERS_FILE, []);
  for(const item of r) reminders.set(item.id, item);
}
function persistAll(){
  const outUsers = {};
  for(const [k,v] of users) outUsers[k]=v;
  safeWriteJson(USERS_FILE,outUsers);
  const outBoards = {};
  for(const [k,v] of boards) outBoards[k]=v;
  safeWriteJson(BOARDS_FILE,outBoards);
  const outNotes = {};
  for(const [k,v] of notes) outNotes[k]=v;
  safeWriteJson(NOTES_FILE,outNotes);
  const outRem = [];
  for(const [k,v] of reminders) outRem.push(v);
  safeWriteJson(REMINDERS_FILE,outRem);
}

// Networking helpers
function fetchText(url){
  return new Promise((resolve,reject) => {
    try{
      const u = new URL(url);
      const lib = u.protocol === "https:" ? https : http;
      const opts = { hostname: u.hostname, path: u.pathname + (u.search||""), method: "GET", port: u.port || (u.protocol==="https:"?443:80), headers: { "User-Agent": VERSION } };
      const req = lib.request(opts, (res) => {
        let data = "";
        res.setEncoding("utf8");
        res.on("data", c => data += c);
        res.on("end", () => resolve(data));
      });
      req.on("error", (e) => reject(e));
      req.setTimeout(10000, () => { req.destroy(); reject(new Error("timeout")); });
      req.end();
    }catch(e){ reject(e); }
  });
}
async function fetchJson(url){
  const txt = await fetchText(url);
  return JSON.parse(txt);
}

// Dice and math
function rollDice(spec){
  const m = String(spec).trim().match(/^(\d*)d(\d+)(?:([+-])(\d+))?$/i);
  if(!m) return {error: "Bad format. Use NdM or NdM+K (e.g., 3d6, d20, 2d8+1)." };
  const n = m[1] ? Number(m[1]) : 1;
  const sides = Number(m[2]);
  const op = m[3]; const k = m[4] ? Number(m[4]) : 0;
  if(n < 1 || n > 100) return {error: "Invalid number of dice (1-100)." };
  if(sides < 2 || sides > 1000) return {error: "Invalid sides (2-1000)." };
  const rolls = [];
  for(let i=0;i<n;i++) rolls.push(randInt(1,sides));
  const sum = rolls.reduce((a,b)=>a+b,0) + (op === "-" ? -k : k);
  return {rolls, sum, spec};
}
function evalMath(expr){
  if(typeof expr !== "string") return {error: "No expression."};
  if(!/^[0-9+\-*/().\s^]+$/.test(expr)) return {error: "Invalid characters."};
  const sanitized = expr.replace(/\^/g,"**");
  try{
    const val = Function(`"use strict"; return (${sanitized});`)();
    if(typeof val !== "number" || !isFinite(val)) return {error: "Invalid result."};
    return {result: val};
  }catch(e){ return {error: "Parse error."}; }
}

// Reminders: schedule deliveries to online users or queue
function deliverReminderToUser(rem, session){
  // If session exists and is logged in as owner, deliver immediately
  if(session && session.user && session.user.username === rem.owner){
    session.writeLine(`\n[Reminder] ${rem.message}`);
    rem.delivered = true;
    persistAll();
    return true;
  }
  // otherwise queue; will be delivered on login
  return false;
}
function deliverDueReminders(){
  const now = Date.now();
  for(const [id, rem] of reminders){
    if(rem.delivered) continue;
    if(rem.at <= now){
      // try deliver to any connected session of owner
      let delivered = false;
      for(const s of clients){
        if(s.user && s.user.username === rem.owner){
          deliverReminderToUser(rem, s);
          delivered = true;
        }
      }
      if(!delivered){
        // mark as pending (rem.delivered false): leave for next login
      } else {
        rem.delivered = true;
        persistAll();
      }
    }
  }
}

// Session abstraction for both telnet sockets and local console
class Session {
  constructor({ socket=null, local=false }){
    this.socket = socket;
    this.local = !!local;
    this.buffer = "";
    this.user = null; // { username }
    this.addr = local ? "local" : (socket.remoteAddress+":"+socket.remotePort);
    this.readline = null;
    this.closed = false;
    this.prompt = "> ";
    this.setup();
  }

  write(data){
    try{
      if(this.local){
        process.stdout.write(data);
      }else{
        this.socket.write(data);
      }
    }catch(e){}
  }
  writeLine(line=""){
    this.write(line+"\r\n");
  }
  clearLine(){
    this.write("\x1b[2K\r");
  }

  async setup(){
    if(this.local){
      this.readline = readline.createInterface({ input: process.stdin, output: process.stdout, prompt: "" });
      this.writeLine(""); // newline start
      this.showWelcome();
      this.showMainMenu();
      this.readline.on("line", (ln) => {
        this.handleLine(ln.replace(/\r?\n/,""));
      });
      this.readline.on("close", () => this.close());
    }else{
      // minimal telnet negotiation: disable local echo? send simple options
      // We keep it simple: just send welcome and prompt
      this.socket.setEncoding("utf8");
      this.socket.on("data", (d) => this.handleLine(String(d).replace(/\r?\n/,"")));
      this.socket.on("close", () => this.close());
      this.socket.on("error", () => this.close());
      this.showWelcome();
      this.showMainMenu();
    }
  }

  close(){
    if(this.closed) return;
    this.closed = true;
    clients.delete(this);
    if(this.local && this.readline){ try{ this.readline.close(); }catch(e){} }
    try{ if(this.socket) this.socket.destroy(); }catch(e){}
  }

  writePrompt(){
    this.write(this.prompt);
  }

  showWelcome(){
    this.writeLine("\x1b[36mMiniBBS Telnet Server\x1b[0m");
    this.writeLine(`\x1b[90m${VERSION}\x1b[0m`);
    this.writeLine("");
  }

  showMainMenu(){
    this.writeLine("Main Menu:");
    this.writeLine("  1) Login");
    this.writeLine("  2) Register");
    this.writeLine("  3) Read boards");
    this.writeLine("  4) Help");
    this.writeLine("  0) Quit");
    this.writePrompt();
    this.state = "MAIN_MENU";
  }

  showUserMenu(){
    const u = this.user && this.user.username ? this.user.username : "guest";
    this.writeLine("");
    this.writeLine(`User: ${u}`);
    this.writeLine("  1) Boards");
    this.writeLine("  2) Post to board");
    this.writeLine("  3) Notes");
    this.writeLine("  4) Reminders");
    this.writeLine("  5) Utilities");
    this.writeLine("  6) Logout");
    this.writeLine("  0) Quit");
    this.writePrompt();
    this.state = "USER_MENU";
  }

  async handleLine(lineRaw){
    const line = (lineRaw || "").trim();
    lastSeen.set((this.user && this.user.username ? this.user.username : this.addr).toLowerCase(), nowTs());
    if(this.state === "MAIN_MENU"){
      if(line === "1") return this.promptLogin();
      if(line === "2") return this.promptRegister();
      if(line === "3") return this.listBoards();
      if(line === "4") return this.showHelp();
      if(line === "0") return this.quit();
      this.writeLine("Invalid selection."); this.writePrompt();
    } else if(this.state === "AWAIT_LOGIN_USER"){
      if(!line){ this.writeLine("Username required."); this.showMainMenu(); return; }
      this._tmpUser = line;
      this.write("Password: ");
      if(this.local){
        // use stdin raw? We'll use readline question with hidden input
        const rlLocal = readline.createInterface({ input: process.stdin, output: process.stdout });
        const stdin = process.stdin;
        stdin.setRawMode && stdin.setRawMode(true);
        let hidden = "";
        const onData = (c) => {
          const ch = String(c);
          if(ch === "\n" || ch === "\r" || ch === "\u0004"){ stdin.setRawMode && stdin.setRawMode(false); stdin.removeListener("data", onData); rlLocal.close(); this.handleLoginPassword(hidden); return; }
          if(ch === "\u0003"){ stdin.setRawMode && stdin.setRawMode(false); stdin.removeListener("data", onData); rlLocal.close(); this.writeLine(""); this.showMainMenu(); return; }
          hidden += ch;
        };
        stdin.on("data", onData);
      }else{
        // for telnet, read next incoming line as password (echoing will show, but acceptable)
        this.state = "AWAIT_LOGIN_PASS";
      }
    } else if(this.state === "AWAIT_LOGIN_PASS"){
      // telnet path: password in clear
      return this.handleLoginPassword(line);
    } else if(this.state === "AWAIT_REGISTER_USER"){
      if(!line){ this.writeLine("Username required."); this.showMainMenu(); return; }
      if(users.has(line)){
        this.writeLine("Username exists."); this.showMainMenu(); return;
      }
      this._tmpUser = line;
      this.write("Password: ");
      this.state = "AWAIT_REGISTER_PASS";
    } else if(this.state === "AWAIT_REGISTER_PASS"){
      if(!line){ this.writeLine("Password required."); this.showMainMenu(); return; }
      // create user
      const salt = genSalt();
      const hash = hashPasswordWithSalt(line, salt);
      users.set(this._tmpUser, { salt, hash, createdAt: nowTs() });
      persistAll();
      this.writeLine("Registered. Please login.");
      this.showMainMenu();
    } else if(this.state === "MAIN_READING_BOARD"){
      // expecting board name to read
      if(!line){ this.showMainMenu(); return; }
      this.readBoard(line);
    } else if(this.state === "USER_MENU"){
      if(line === "1") return this.listBoards();
      if(line === "2") return this.promptPostBoard();
      if(line === "3") return this.notesMenu();
      if(line === "4") return this.remindersMenu();
      if(line === "5") return this.utilitiesMenu();
      if(line === "6") return this.logout();
      if(line === "0") return this.quit();
      this.writeLine("Invalid selection."); this.writePrompt();
    } else if(this.state === "POST_BOARD_NAME"){
      if(!line){ this.showUserMenu(); return; }
      this._postBoard = line;
      this.writeLine("Enter message (single line).");
      this.writePrompt();
      this.state = "POST_BOARD_TEXT";
    } else if(this.state === "POST_BOARD_TEXT"){
      const board = this._postBoard;
      const text = line;
      if(!boards.has(board)) boards.set(board, []);
      const arr = boards.get(board);
      const id = Date.now()+"_"+Math.random().toString(36).slice(2,6);
      arr.push({ id, author: this.user.username, text, ts: nowTs() });
      persistAll();
      this.writeLine("Posted.");
      this.showUserMenu();
    } else if(this.state === "NOTES_MENU"){
      // options: 1 add,2 show,3 search,0 back
      if(line === "1"){ this.write("Key: "); this.state="NOTE_ADD_KEY"; return; }
      if(line === "2"){ this.write("Key: "); this.state="NOTE_SHOW_KEY"; return; }
      if(line === "3"){ this.write("Term: "); this.state="NOTE_SEARCH_TERM"; return; }
      if(line === "0"){ this.showUserMenu(); return; }
      this.writeLine("Invalid selection."); this.writePrompt();
    } else if(this.state === "NOTE_ADD_KEY"){
      if(!line){ this.writeLine("Cancelled."); this.showUserMenu(); return; }
      this._noteKey = line.toLowerCase();
      this.write("Text: ");
      this.state = "NOTE_ADD_TEXT";
    } else if(this.state === "NOTE_ADD_TEXT"){
      const key = this._noteKey; const text = line;
      const u = this.user.username;
      if(!notes.has(u)) notes.set(u, {});
      notes.get(u)[key] = { text, createdAt: nowTs() };
      persistAll();
      this.writeLine("Note saved.");
      this.showUserMenu();
    } else if(this.state === "NOTE_SHOW_KEY"){
      const key = line.toLowerCase();
      const u = this.user.username;
      if(!notes.has(u) || !notes.get(u)[key]){ this.writeLine("No such note."); this.showUserMenu(); return; }
      this.writeLine(notes.get(u)[key].text);
      this.showUserMenu();

    } else if(this.state === "NOTE_SEARCH_TERM"){
      const term = line.toLowerCase();
      const u = this.user.username;
      const hits = [];
      if(notes.has(u)){
        for(const k of Object.keys(notes.get(u))){
          const v = notes.get(u)[k];
          if(k.includes(term) || v.text.toLowerCase().includes(term)) hits.push(k);
        }
      }
      if(hits.length) this.writeLine("Matches: " + hits.join(", ")); else this.writeLine("No matches.");
      this.showUserMenu();

    } else if(this.state === "REMINDERS_MENU"){
      // 1 set,2 list,0 back
      if(line === "1"){ this.write("Minutes from now: "); this.state="REM_SET_MIN"; return; }
      if(line === "2"){
        // list reminders for user
        const list = [];
        for(const r of reminders.values()) if(r.owner === this.user.username) list.push(r);
        if(list.length===0) this.writeLine("No reminders.");
        else{
          for(const r of list) this.writeLine(`${r.id} @ ${new Date(r.at).toISOString()}: ${r.message} ${r.delivered?"(delivered)":""}`);
        }
        this.showUserMenu();
        return;
      }
      if(line === "0"){ this.showUserMenu(); return; }
      this.writeLine("Invalid."); this.writePrompt();

    } else if(this.state === "REM_SET_MIN"){
      const mins = Number(line);
      if(Number.isNaN(mins) || mins<=0){ this.writeLine("Invalid minutes."); this.showUserMenu(); return; }
      this._remMinutes = mins;
      this.write("Message: "); this.state="REM_SET_MSG";

    } else if(this.state === "REM_SET_MSG"){
      const msg = line;
      const id = Date.now()+"_"+Math.random().toString(36).slice(2,6);
      const at = Date.now() + (this._remMinutes*60000);
      const rem = { id, owner: this.user.username, message: msg, at, delivered: false };
      reminders.set(id, rem);
      persistAll();
      this.writeLine("Reminder set.");
      this.showUserMenu();

    } else if(this.state === "UTIL_MENU"){
      // 1 dice,2 math,3 hash,4 quote,5 weather,6 seen,7 stardate,8 time,9 temp,0 back
      if(line === "1"){ this.write("Roll (NdM[+/-K]): "); this.state="UTIL_ROLL"; return; }
      if(line === "2"){ this.write("Expr: "); this.state="UTIL_MATH"; return; }
      if(line === "3"){ this.write("Alg and text: "); this.state="UTIL_HASH"; return; }
      if(line === "4"){ await this.utilQuote(); this.showUserMenu(); return; }
      if(line === "5"){ this.write("Location: "); this.state="UTIL_WEATHER"; return; }
      if(line === "6"){ this.write("Nick: "); this.state="UTIL_SEEN"; return; }
      if(line === "7"){ this.writeLine(toStardate()); this.showUserMenu(); return; }
      if(line === "8"){ this.write("UTC or offset (+HH): "); this.state="UTIL_TIME"; return; }
      if(line === "9"){ this.write("Value and unit C|F: "); this.state="UTIL_TEMP"; return; }
      if(line === "0"){ this.showUserMenu(); return; }
      this.writeLine("Invalid."); this.writePrompt();

    } else if(this.state === "UTIL_ROLL"){
      const r = rollDice(line);
      if(r.error) this.writeLine(r.error); else this.writeLine(`${r.spec}: [${r.rolls.join(", ")}] => ${r.sum}`);
      this.showUserMenu();

    } else if(this.state === "UTIL_MATH"){
      const r = evalMath(line);
      if(r.error) this.writeLine(r.error); else this.writeLine(String(r.result));
      this.showUserMenu();

    } else if(this.state === "UTIL_HASH"){
      const sp = line.split(/\s+/);
      if(sp.length<2){ this.writeLine("Usage: alg text"); this.showUserMenu(); return; }
      const alg = sp[0]; const txt = sp.slice(1).join(" ");
      try{ const h = crypto.createHash(alg).update(txt,"utf8").digest("hex"); this.writeLine(h); }catch(e){ this.writeLine("Unsupported algorithm."); }
      this.showUserMenu();

    } else if(this.state === "UTIL_WEATHER"){
      const loc = line || "local";
      const url = WEATHER_API.replace("{loc}", encodeURIComponent(loc));
      try{ const txt = await fetchText(url); this.writeLine((txt.split("\n")[0]||"No data").trim()); }catch(e){ this.writeLine("Weather lookup failed."); }
      this.showUserMenu();

    } else if(this.state === "UTIL_SEEN"){
      const q = line.toLowerCase(); const ts = lastSeen.get(q);
      if(ts) this.writeLine(formatSeen(line, ts)); else this.writeLine(`No record of ${line}.`);
      this.showUserMenu();

    } else if(this.state === "UTIL_TIME"){
      const loc = line || "UTC";
      if(loc.toUpperCase() === "UTC") this.writeLine(new Date().toISOString().replace("T"," ").replace("Z"," (UTC)"));
      else {
        const m2 = loc.match(/^([+-]?)(\d{1,2})$/);
        if(m2){ const sign = m2[1]==="-"?-1:1; const hrs = Number(m2[2]); this.writeLine(utcNowString(sign*hrs)); }
        else this.writeLine("Use UTC or offset like +02");
      }
      this.showUserMenu();

    } else if(this.state === "UTIL_TEMP"){
      const sp = line.split(/\s+/);
      if(sp.length<2) this.writeLine("Usage: <value> <C|F>");
      else{
        const val = Number(sp[0]); if(Number.isNaN(val)) this.writeLine("Invalid number."); else this.writeLine(convertTemp(val, sp[1]));
      }
      this.showUserMenu();

    } else {
      // fallback: treat as command when logged in
      if(line === "quit" || line === "exit"){ return this.quit(); }
      this.writeLine("Unknown input."); this.writePrompt();
    }
  }

  // Login flow helper for password collected
  handleLoginPassword(pw){
    const u = this._tmpUser;
    if(!users.has(u)){ this.writeLine("No such user."); this.showMainMenu(); return; }
    const rec = users.get(u);
    const h = hashPasswordWithSalt(pw, rec.salt);
    if(h !== rec.hash){ this.writeLine("Incorrect password."); this.showMainMenu(); return; }
    this.user = { username: u };
    this.writeLine(`Welcome, ${u}!`);
    // deliver queued reminders
    for(const rem of reminders.values()){
      if(rem.owner === u && !rem.delivered && rem.at <= Date.now()){
        this.writeLine(`[Reminder] ${rem.message}`);
        rem.delivered = true;
      }
    }
    persistAll();
    this.showUserMenu();
  }

  // Menu actions
  showHelp(){ this.writeLine("Help: Use menu numbers. After login you can post/read boards, manage notes and reminders."); this.showMainMenu(); }

  quit(){ this.writeLine("Goodbye."); this.close(); }

  promptLogin(){ this.write("Username: "); this.state="AWAIT_LOGIN_USER"; this.writePrompt(); }
  promptRegister(){ this.write("Choose username: "); this.state="AWAIT_REGISTER_USER"; this.writePrompt(); }

  listBoards(){
    this.writeLine("Boards:");
    if(boards.size===0) this.writeLine("  (none)");
    for(const [k,v] of boards) this.writeLine(`  ${k} (${v.length} posts)`);
    this.writeLine("Enter board name to read or blank to return:");
    this.state = "MAIN_READING_BOARD";
    this.writePrompt();
  }

  readBoard(name){
    if(!boards.has(name)){ this.writeLine("No such board."); this.showMainMenu(); return; }
    const posts = boards.get(name);
    this.writeLine(`--- ${name} ---`);
    for(const p of posts.slice(-20)){ this.writeLine(`${p.id} | ${p.author} @ ${new Date(p.ts).toISOString()}`); this.writeLine(p.text); this.writeLine("---"); }
    this.showMainMenu();
  }

  promptPostBoard(){
    if(!this.user){ this.writeLine("Login required."); this.showMainMenu(); return; }
    this.write("Board name: "); this.state="POST_BOARD_NAME"; this.writePrompt();
  }

  notesMenu(){
    if(!this.user){ this.writeLine("Login required."); this.showMainMenu(); return; }
    this.writeLine("Notes: 1)add 2)show 3)search 0)back");
    this.state="NOTES_MENU";
    this.writePrompt();
  }

  remindersMenu(){
    if(!this.user){ this.writeLine("Login required."); this.showMainMenu(); return; }
    this.writeLine("Reminders: 1)set 2)list 0)back");
    this.state="REMINDERS_MENU";
    this.writePrompt();
  }

  async utilitiesMenu(){
    this.writeLine("Utilities:");
    this.writeLine("  1) Dice roll");
    this.writeLine("  2) Math");
    this.writeLine("  3) Hash");
    this.writeLine("  4) Quote");
    this.writeLine("  5) Weather");
    this.writeLine("  6) Seen");
    this.writeLine("  7) Stardate");
    this.writeLine("  8) Time");
    this.writeLine("  9) Temp");
    this.writeLine("  0) Back");
    this.state = "UTIL_MENU";
    this.writePrompt();
  }

  async utilQuote(){
    const api = "https://api.quotable.io/random";
    try{
      const j = await fetchJson(api);
      if(j && j.content) this.writeLine(`${j.content} — ${j.author}`);
      else this.writeLine(localQuotes[randInt(0,localQuotes.length-1)]);
    }catch(e){
      this.writeLine(localQuotes[randInt(0,localQuotes.length-1)]);
    }
  }

  logout(){
    this.user = null;
    this.writeLine("Logged out.");
    this.showMainMenu();
  }
}

// Server setup
loadAll();
const server = net.createServer((socket) => {
  const s = new Session({ socket });
  clients.add(s);
  s.writeLine(`Connected to MiniBBS. Type numbers to navigate. (${new Date().toISOString()})`);
});
server.on("error", (e) => console.error("Server error:", e));
server.listen(PORT, HOST, () => {
  console.log(`MiniBBS listening on ${HOST}:${PORT}`);
  // create local admin session
  const localSession = new Session({ local: true });
  clients.add(localSession);
  // Periodic tasks
  setInterval(() => {
    deliverDueReminders();
  }, 30000);
  setInterval(() => { persistAll(); }, 60000);
});
