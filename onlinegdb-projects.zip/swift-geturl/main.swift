import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

// ---------------------------------------------------------------
// MARK: - MD5 Implementation (Your original, lightly optimized)
// ---------------------------------------------------------------

struct MD5 {
    private static func rotateLeft(_ x: UInt32, _ n: UInt32) -> UInt32 {
        (x << n) | (x >> (32 - n))
    }

    private static func F(_ x: UInt32, _ y: UInt32, _ z: UInt32) -> UInt32 { (x & y) | (~x & z) }
    private static func G(_ x: UInt32, _ y: UInt32, _ z: UInt32) -> UInt32 { (x & z) | (y & ~z) }
    private static func H(_ x: UInt32, _ y: UInt32, _ z: UInt32) -> UInt32 { x ^ y ^ z }
    private static func I(_ x: UInt32, _ y: UInt32, _ z: UInt32) -> UInt32 { y ^ (x | ~z) }

    private static let S: [UInt32] = [
        7,12,17,22, 7,12,17,22, 7,12,17,22, 7,12,17,22,
        5, 9,14,20, 5, 9,14,20, 5, 9,14,20, 5, 9,14,20,
        4,11,16,23, 4,11,16,23, 4,11,16,23, 4,11,16,23,
        6,10,15,21, 6,10,15,21, 6,10,15,21, 6,10,15,21
    ]

    private static let T: [UInt32] = (0..<64).map {
        UInt32(abs(sin(Double($0 + 1))) * 4294967296.0)
    }

    static func digest(_ string: String) -> [UInt8] {
        var msg = Array(string.utf8)
        let originalBits = UInt64(msg.count) * 8

        msg.append(0x80)
        while msg.count % 64 != 56 { msg.append(0) }

        for i in 0..<8 {
            msg.append(UInt8((originalBits >> (8 * i)) & 0xff))
        }

        var a: UInt32 = 0x67452301
        var b: UInt32 = 0xefcdab89
        var c: UInt32 = 0x98badcfe
        var d: UInt32 = 0x10325476

        for offset in stride(from: 0, to: msg.count, by: 64) {
            var M = [UInt32](repeating: 0, count: 16)
            for j in 0..<16 {
                let k = offset + j * 4
                M[j] = UInt32(msg[k]) |
                       UInt32(msg[k+1]) << 8 |
                       UInt32(msg[k+2]) << 16 |
                       UInt32(msg[k+3]) << 24
            }

            var A = a, B = b, C = c, D = d

            for i in 0..<64 {
                let f: UInt32
                let g: Int
                switch i {
                case 0..<16:  f = F(B, C, D); g = i
                case 16..<32: f = G(B, C, D); g = (5*i + 1) % 16
                case 32..<48: f = H(B, C, D); g = (3*i + 5) % 16
                default:      f = I(B, C, D); g = (7*i) % 16
                }

                let temp = D
                D = C
                C = B
                B = B &+ rotateLeft(A &+ f &+ M[g] &+ T[i], S[i])
                A = temp
            }

            a &+= A; b &+= B; c &+= C; d &+= D
        }

        return [a, b, c, d].flatMap { w in
            (0..<4).map { i in UInt8((w >> (8*i)) & 0xff) }
        }
    }

    static func hex(_ s: String) -> String {
        digest(s).map { String(format: "%02x", $0) }.joined()
    }
}

// ---------------------------------------------------------------
// MARK: - Metadata
// ---------------------------------------------------------------

struct Metadata: Codable {
    let url: String
    let etag: String?
    let downloadedAt: String
    let size: Int
}

let jsonEncoder: JSONEncoder = {
    let enc = JSONEncoder()
    enc.outputFormatting = [.prettyPrinted, .sortedKeys]
    return enc
}()

// ---------------------------------------------------------------
// MARK: - MAIN PROGRAM
// ---------------------------------------------------------------

// CHANGE THIS for OnlineGDB demo:
let urlString = "https://jimf99.github.io"

guard let url = URL(string: urlString) else {
    print("Invalid URL: \(urlString)")
    exit(1)
}

let cacheName = "cache_\(MD5.hex(urlString))"
let fileURL = URL(fileURLWithPath: cacheName)
let metaURL = fileURL.appendingPathExtension("json")

// read old ETag if present
var oldEtag: String? = nil
if let data = try? Data(contentsOf: metaURL),
   let meta = try? JSONDecoder().decode(Metadata.self, from: data) {
    oldEtag = meta.etag
    print("Found cached metadata with ETag: \(oldEtag ?? "none")")
}

var request = URLRequest(url: url)
if let oldEtag {
    request.addValue(oldEtag, forHTTPHeaderField: "If-None-Match")
}

// ---------------------------------------------------------------
// MARK: - URLSession synchronous wrapper
// ---------------------------------------------------------------

let semaphore = DispatchSemaphore(value: 0)
var resultData: Data?
var resultResponse: URLResponse?
var resultError: Error?

URLSession.shared.dataTask(with: request) { data, response, error in
    resultData = data
    resultResponse = response
    resultError = error
    semaphore.signal()
}.resume()

semaphore.wait()

// ---------------------------------------------------------------
// MARK: - Handle response
// ---------------------------------------------------------------

if let error = resultError {
    print("Network error:", error.localizedDescription)
    exit(1)
}

guard let http = resultResponse as? HTTPURLResponse else {
    print("No HTTP response")
    exit(1)
}

if http.statusCode == 304 {
    print("✔ Not modified — using cached file.")
    exit(0)
}

guard http.statusCode >= 200 && http.statusCode <= 299 else {
    print("HTTP error:", http.statusCode)
    exit(1)
}

guard let data = resultData else {
    print("No data received")
    exit(1)
}

// ---------------------------------------------------------------
// MARK: - Save file
// ---------------------------------------------------------------

do {
    try data.write(to: fileURL, options: .atomic)
    print("✔ Saved file:", fileURL.path)
} catch {
    print("Error saving file:", error)
    exit(1)
}

// ---------------------------------------------------------------
// MARK: - Save metadata JSON
// ---------------------------------------------------------------

let metadata = Metadata(
    url: urlString,
    etag: http.value(forHTTPHeaderField: "ETag"),
    downloadedAt: ISO8601DateFormatter().string(from: Date()),
    size: data.count
)

if let metaData = try? jsonEncoder.encode(metadata) {
    try? metaData.write(to: metaURL, options: .atomic)
    print("✔ Saved metadata:", metaURL.path)
}

print("Done.")
