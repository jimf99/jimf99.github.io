using System;

public class SingleCharInput
{
    public static void Main(string[] args)
    {
        // Motor control variables
        int front = 0;
        int back = 0;
        int left = 0;
        int right = 0;
        
        // PID control variables
        float angle = 0.0f;
        float kp = 0.0f;
        float kd = 0.0f;
        float kp_speed = 0.0f;
        float ki_speed = 0.0f;
        float kp_turn = 0.0f;
        float kd_turn = 0.0f;

        while (true)
        {
            ConsoleKeyInfo keyInfo = Console.ReadKey();
            char upperChar = char.ToUpper(keyInfo.KeyChar); // Convert input to uppercase

            // Handle input character commands
            switch (upperChar)
            {
                case 'F':
                    front = 250; // Move forward
                    break;
                case 'B':
                    back = -250; // Move backward
                    break;
                case 'L':
                    left = 1; // Turn left
                    break;
                case 'R':
                    right = 1; // Turn right
                    break;
                case 'S':
                    front = 0; back = 0; left = 0; right = 0; // Stop all movement
                    break;
                case 'Q':
                    Console.WriteLine(angle); // Output current angle
                    break;
                case 'P':
                    kp += 0.5f; // Adjust proportional gain
                    Console.WriteLine(kp); 
                    break;
                case 'O':
                    kp -= 0.5f; 
                    Console.WriteLine(kp); 
                    break;
                case 'I':
                    kd += 0.02f; // Adjust derivative gain
                    Console.WriteLine(kd); 
                    break;
                case 'U':
                    kd -= 0.02f; 
                    Console.WriteLine(kd); 
                    break;
                case 'Y':
                    kp_speed += 0.05f; // Adjust speed proportional gain
                    Console.WriteLine(kp_speed); 
                    break;
                case 'T':
                    kp_speed -= 0.05f; 
                    Console.WriteLine(kp_speed); 
                    break;
                case 'G':
                    ki_speed += 0.01f; // Adjust integral gain
                    Console.WriteLine(ki_speed); 
                    break;
                case 'H':
                    ki_speed -= 0.01f; 
                    Console.WriteLine(ki_speed); 
                    break;
                case 'J':
                    kp_turn += 0.4f; // Adjust turn proportional gain
                    Console.WriteLine(kp_turn); 
                    break;
                case 'K':
                    kp_turn -= 0.4f; 
                    Console.WriteLine(kp_turn); 
                    break;
                case 'N':
                    kd_turn += 0.01f; // Adjust turn derivative gain
                    Console.WriteLine(kd_turn); 
                    break;
                case 'M':
                    kd_turn -= 0.01f; 
                    Console.WriteLine(kd_turn); 
                    break;
            }

            // Debug output for direction
            string msg = string.Empty;
            switch (upperChar)
            {
                case 'F': msg = "FORWARD"; break;
                case 'B': msg = "BACK"; break;
                case 'L': msg = "LEFT"; break;
                case 'R': msg = "RIGHT"; break;
            }

            if (!string.IsNullOrEmpty(msg))
            {
                Console.WriteLine(msg);
            }

            // Check if Shift key is pressed (currently no action taken)
            bool shiftPressed = (keyInfo.Modifiers.HasFlag(ConsoleModifiers.Shift));
            if (shiftPressed)
            {
                // Handle shift functionality if needed
            }
        }
    }
}
