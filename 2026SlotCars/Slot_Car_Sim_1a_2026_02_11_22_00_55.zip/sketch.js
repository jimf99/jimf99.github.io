/** * F1 SLOT CARS - PERSISTENT COLOR & SMOOTH THROTTLE
 * P1: 'W' (RED) | P2/AI: 'UP_ARROW' (BLUE)
 */

let gameState = "START";
let numPlayers = 1;
let trackPoints = [];
let cars = [];
let telemetryUI = [];

function setup() {
  createCanvas(800, 600);
  
  trackPoints = [
    {x: 150, y: 500}, {x: 650, y: 500}, 
    {x: 750, y: 400}, {x: 600, y: 350}, 
    {x: 700, y: 200}, {x: 400, y: 100}, 
    {x: 100, y: 100}, {x: 150, y: 250}, 
    {x: 350, y: 350}, {x: 100, y: 400}  
  ];

  cars = [
    new SlotCar("RED TEAM", color(255, 0, 0), 87, -12),
    new SlotCar("BLUE TEAM", color(0, 100, 255), UP_ARROW, 12)
  ];

  setupDOM();
}

function setupDOM() {
  let container = createDiv('').style('position','absolute').style('top','20px').style('right','20px')
    .style('font-family','monospace').style('color','#fff').style('background', 'rgba(0,0,0,0.8)')
    .style('padding','15px').style('border-left','5px solid #e10600').style('width', '180px');

  for(let i = 0; i < cars.length; i++) {
    let div = createDiv('').parent(container).style('margin-bottom','15px');
    telemetryUI.push(div);
  }
}

function draw() {
  background(30);
  if (gameState === "START") {
    drawStartScreen();
  } else {
    drawTrack();
    cars.forEach((car, i) => {
      car.update(i === 1 && numPlayers === 1);
      car.display();
      updateTelemetry(i);
    });
  }
}

function drawTrack() {
  fill(15, 30, 15); noStroke();
  beginShape(); for (let p of trackPoints) vertex(p.x, p.y); endShape(CLOSE);
  noFill(); stroke(45); strokeWeight(55);
  beginShape(); for (let p of trackPoints) curveVertex(p.x, p.y); endShape(CLOSE);
  stroke(220, 180, 0, 120); strokeWeight(2);
  beginShape(); for (let p of trackPoints) curveVertex(p.x, p.y); endShape(CLOSE);
  stroke(255); strokeWeight(8); line(150, 470, 150, 530);
}

class SlotCar {
  constructor(name, col, key, laneOffset) {
    this.name = name; this.col = col; this.key = key; this.laneOffset = laneOffset;
    this.progress = 0; this.speed = 0; this.topSpeed = 0; this.laps = 0;
    this.isCrashed = false; this.crashPos = createVector(0,0); this.crashVel = createVector(0,0);
    this.crashTimer = 0;
    
    // Physics & Throttle Smoothing
    this.maxSpeedConst = 0.007;
    this.accelPower = 0.00008; // How fast engine gains power
    this.friction = 0.988;    // Resistance
    this.crashThreshold = 0.0032; // Forgiving cornering
  }

  update(isAI) {
    if (this.isCrashed) {
      this.crashPos.add(this.crashVel);
      this.crashVel.mult(0.96);
      this.crashTimer--;
      if (this.crashTimer <= 0) {
        this.isCrashed = false;
        this.speed = 0;
      }
      return;
    }

    // Input smoothing: check if key is held
    let isRequestingPower = isAI ? this.runAI() : keyIsDown(this.key);
    
    // Applying power gradually rather than binary ON/OFF
    if (isRequestingPower) {
      this.speed += this.accelPower;
    } else {
      this.speed *= this.friction;
    }

    this.speed = constrain(this.speed, 0, this.maxSpeedConst);

    // Physics check for cornering
    let p1 = this.getPointAt(this.progress);
    let p2 = this.getPointAt(this.progress + 0.005);
    let v1 = createVector(p2.x - p1.x, p2.y - p1.y);
    let v2 = createVector(this.getPointAt(this.progress + 0.01).x - p2.x, this.getPointAt(this.progress + 0.01).y - p2.y);
    let turnSharpness = abs(v1.angleBetween(v2));

    if (this.speed * turnSharpness > this.crashThreshold) {
      this.isCrashed = true;
      this.crashPos = createVector(p1.x, p1.y);
      this.crashVel = v1.setMag(this.speed * 600); 
      this.crashTimer = 80; 
      return;
    }

    this.progress += this.speed;
    let dispSpeed = floor(this.speed * 40000);
    if (dispSpeed > this.topSpeed) this.topSpeed = dispSpeed;
    if (this.progress >= 1) { this.progress = 0; this.laps++; }
  }

  runAI() {
    let p1 = this.getPointAt(this.progress);
    let p2 = this.getPointAt(this.progress + 0.06);
    let curv = abs(createVector(p2.x-p1.x, p2.y-p1.y).angleBetween(createVector(this.getPointAt(this.progress + 0.12).x-p2.x, this.getPointAt(this.progress + 0.12).y-p2.y)));
    if (curv > 0.15 && this.speed > 0.004) return false;
    return this.speed < 0.006;
  }

  display() {
    let x, y, angle;
    if (this.isCrashed) {
      x = this.crashPos.x; y = this.crashPos.y; angle = this.crashVel.heading();
    } else {
      let pos = this.getPointAt(this.progress);
      let next = this.getPointAt(this.progress + 0.001);
      x = pos.x; y = pos.y; angle = atan2(next.y - y, next.x - x);
    }

    push();
    translate(x, y); rotate(angle);
    if (!this.isCrashed) translate(0, this.laneOffset);
    
    // THE BODY: Color remains identical whether crashed or racing
    noStroke();
    fill(this.col); 
    rectMode(CENTER);
    rect(0, 0, 32, 16, 4); 
    
    // If crashed, add a slight smoke/dirt effect nearby instead of changing car color
    if (this.isCrashed && this.crashTimer > 40) {
      fill(200, 200, 200, 100);
      ellipse(-15, random(-5,5), 10, 10);
    }

    fill(20); rect(-13, 0, 4, 22); // Rear Wing
    fill(255, 180); rect(6, 0, 9, 9, 2); // Cockpit
    pop();
  }

  getPointAt(t) {
    t = (t + 1) % 1;
    let i = floor(t * trackPoints.length);
    let p = [trackPoints[(i + trackPoints.length - 1) % trackPoints.length], trackPoints[i], trackPoints[(i + 1) % trackPoints.length], trackPoints[(i + 2) % trackPoints.length]];
    return { x: curvePoint(p[0].x, p[1].x, p[2].x, p[3].x, (t * trackPoints.length) - i), y: curvePoint(p[0].y, p[1].y, p[2].y, p[3].y, (t * trackPoints.length) - i) };
  }
}

function updateTelemetry(i) {
  let c = cars[i];
  let cStr = i === 0 ? "#ff4444" : "#44aaff";
  telemetryUI[i].html(`
    <b style="color:${cStr}">${c.name}</b><br>
    LAP: ${c.laps} | KM/H: ${floor(c.speed * 40000)}<br>
    ${c.isCrashed ? '<span style="color:yellow">RECOVERING...</span>' : 'STATUS: OK'}
  `);
}

function drawStartScreen() {
  fill(255); textAlign(CENTER); textSize(24);
  text("F1 SLOT CAR SIM", width/2, height/2 - 40);
  textSize(16); text("1: VS AI | 2: PVP\nW (RED) | UP (BLUE)", width/2, height/2 + 10);
}

function keyPressed() { if (gameState === "START" && (key === '1' || key === '2')) { numPlayers = int(key); gameState = "PLAY"; } }