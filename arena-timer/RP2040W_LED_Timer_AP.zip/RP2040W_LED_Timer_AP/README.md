# RP2040W LED Timer (Access Point)

## Overview
Single-file Raspberry Pi Pico W project that creates its own Wi-Fi access point and serves
a browser-based p5.js LED countdown timer.

## Features
- No router required
- Offline operation
- One .ino file
- p5.js served locally from flash
- OBS / show safe

## Wi-Fi
SSID: LED_TIMER_AP  
Password: ledtimer123  
URL: http://192.168.4.1

## Setup
1. Install Arduino-Pico core (Earle Philhower)
2. Select board: Raspberry Pi Pico W
3. Open RP2040W_LED_Timer_AP.ino
4. Paste full contents of p5.min.js where indicated
5. Upload

## Notes
- p5.min.js ~600KB, fits in Pico W flash
- Everything runs client-side in browser
