cls
powershell.exe -ExecutionPolicy Bypass .\run_editor.ps1
pause
cls

