using System.Text;
using System.Text.Json;
using Terminal.Gui.App;
using Terminal.Gui.Configuration;
using Terminal.Gui.Drawing;
using Terminal.Gui.ViewBase;
using Terminal.Gui.Views;
// "Attribute" alone is ambiguous with System.Attribute, so alias it.
using TgAttribute = Terminal.Gui.Drawing.Attribute;

const string AmberScheme = "Amber";

string filePath = Path.GetFullPath("untitled.txt");
using HttpClient http = new () { Timeout = TimeSpan.FromSeconds (10) };

// True-color amber on black (inverse when focused).
Color amber = new (0xFF, 0xB0, 0x00);
Color black = new (0x00, 0x00, 0x00);

SchemeManager.AddScheme (AmberScheme, new Scheme
{
    Normal = new TgAttribute (amber, black),
    Focus = new TgAttribute (black, amber)
});

using IApplication app = Application.Create ();
app.Init ();

using Window window = new ()
{
    Title = " AMBER TUI EDITOR (Esc to quit) ",
    SchemeName = AmberScheme,
    X = 0,
    Y = 0,
    Width = Dim.Fill (),
    Height = Dim.Fill ()
};

TextView editor = new ()
{
    X = 0,
    Y = 0,
    Width = Dim.Fill (),
    Height = Dim.Fill () - 3,
    Text = "Welcome to your amber terminal editor.\nType text here..."
};

Button btnLoad = new () { Text = "_Load", X = 1, Y = Pos.Bottom (editor) + 1 };
Button btnSave = new () { Text = "_Save", X = Pos.Right (btnLoad) + 2, Y = Pos.Top (btnLoad) };
Button btnSend = new () { Text = "S_end to API", X = Pos.Right (btnSave) + 2, Y = Pos.Top (btnLoad) };

Label status = new ()
{
    Text = "Status: idle",
    X = 1,
    Y = Pos.Bottom (btnLoad),
    Width = Dim.Fill ()
};

btnLoad.Accepting += (_, e) =>
{
    try
    {
        if (File.Exists (filePath))
        {
            editor.Text = File.ReadAllText (filePath);
            status.Text = $"Status: loaded {filePath}";
        }
        else
        {
            status.Text = $"Status: '{filePath}' not found";
        }
    }
    catch (Exception ex)
    {
        status.Text = $"Load error: {ex.Message}";
    }

    e.Handled = true;
};

btnSave.Accepting += (_, e) =>
{
    try
    {
        File.WriteAllText (filePath, editor.Text);
        status.Text = $"Status: saved {filePath}";
    }
    catch (Exception ex)
    {
        status.Text = $"Save error: {ex.Message}";
    }

    e.Handled = true;
};

btnSend.Accepting += async (_, e) =>
{
    e.Handled = true;
    status.Text = "Status: transmitting to API...";
    string text = editor.Text;

    string result;
    try
    {
        // Serialize properly so quotes/newlines in the text can't break the JSON.
        string json = JsonSerializer.Serialize (new { title = "note", body = text, userId = 1 });
        using StringContent content = new (json, Encoding.UTF8, "application/json");
        using HttpResponseMessage response = await http.PostAsync ("https://jsonplaceholder.typicode.com/posts", content);

        if (response.IsSuccessStatusCode)
        {
            string body = (await response.Content.ReadAsStringAsync ()).Replace ('\n', ' ').Replace ('\r', ' ');
            result = $"API success: {(body.Length > 60 ? body[..60] : body)}...";
        }
        else
        {
            result = $"API failure: {(int)response.StatusCode} {response.StatusCode}";
        }
    }
    catch (Exception ex)
    {
        result = $"API error: {ex.Message}";
    }

    // The await may resume off the UI thread, so marshal the update back.
    app.Invoke (() => status.Text = result);
};

window.Add (editor, btnLoad, btnSave, btnSend, status);
app.Run (window);