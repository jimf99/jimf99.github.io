ScanSeq Web Javascript version                      

Online : [https://jeonghopark.github.io/scanseqjs/](https://jeonghopark.github.io/scanseqjs/)               

p5js            
Tone.js                

![capture.jpg](capture.jpg)             


[https://experiments.withgoogle.com/chrome/scan-sequencer](https://experiments.withgoogle.com/chrome/scan-sequencer)


version iOS version Video.                  
[https://vimeo.com/133545595](https://vimeo.com/133545595)                    