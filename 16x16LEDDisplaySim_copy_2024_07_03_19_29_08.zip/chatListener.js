/*
	Project: Javascript Chat Listener
	Project By: JimFyyc, Calgary Alberta Canada
	Requires: ComfyJS Library
	Date Started: March 7, 2021
*/

var streamId="jimfyyc";
var tmp="";

function checkTextareaHeight(){
	var textarea = document.getElementById("text1");
	if(textarea.selectionStart == textarea.selectionEnd) {
		textarea.scrollTop = textarea.scrollHeight;
	}
}

function appendChatMessage(msg) {
	tmp=document.getElementById("text1").value;
	document.getElementById("text1").value=tmp+msg+"\n";
	checkTextareaHeight();
} 

ComfyJS.onCommand = ( user, command, message, flags, extra ) => {
	appendChatMessage(user+":!"+command+" "+message);
	doCommand(user, command, message, flags, extra);
} // onCommand

ComfyJS.onChat = ( user, message, flags, self, extra ) => {
	var msgTemp="";
	msgTemp+=user+":";
	msgTemp+=message+" ";
	// msgTemp+=JSON.stringify(flags)+" "+JSON.stringify(self)+" "+JSON.stringify(extra);
	doChat(user, command, message, flags, extra);
	appendChatMessage(msgTemp);
}// onChat

ComfyJS.Init(streamId);
