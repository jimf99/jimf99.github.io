/*
	Project: 16x16 LED Display Simulator
	Date Started: March 17, 2021
	Project by: JimFyyc, Calgary Alberta Canada
	Inspired by: Twitch.tv/LorentzFactr
*/

let xMax = 16;
let yMax = 16;
let sc = 12;
let colr = [];
var cmdsBuff = new Array();
var doDrawCmds = 0;
var doRandomPixels = 0;

function setup() {
  createCanvas(xMax * sc, yMax * sc);
  for (let y = 0; y < yMax; y++) {
    for (let x = 0; x < xMax; x++) {
      let index = (y * xMax) + x;
      colr.push(color(255, 255, 255));
    }
  }
}

function rgbToHex(vals) {
  var r = vals[0];
  var g = vals[1];
  var b = vals[2];
  return ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
}

function hexToRgb(hex) {
  var bigint = parseInt(hex, 16);
  var r = (bigint >> 16) & 255;
  var g = (bigint >> 8) & 255;
  var b = bigint & 255;
  var rgbOut = new Array(r, g, b);
  return rgbOut;
}

function doSave() {
  var result = "";
  var tmp = JSON.stringify(colr);
  var tmpVals = [];
  for (index = 0; index < colr.length; index++) {
    var c = colr[index].levels;
    c = rgbToHex(c);
    tmpVals.push(c);
  }
  result = JSON.stringify(tmpVals);
  document.getElementById("save1").value = result;
  clearInput('input1');
}

var input1 = document.getElementById("input1");
input1.addEventListener("keyup", function(event) {
  if (event.keyCode === 13) {
    doButton();
    event.preventDefault();
  }
});

function putVal(theItem, theVal) {
  document.getElementById(theItem).value = theVal;

}

function clearInput(theItem) {
  document.getElementById(theItem).value = '';
}

function getInput(theItem) {
  var result = "";
  result = document.getElementById(theItem).value;
  return result;
}

function imgTransfer(theImg) {
  if (theImg > -1 && theImg < img.length) {
    var t = img[theImg];
    for (i = 0; i < t.length; i++) {
      var c1 = hexToRgb(t[i]);
      colr[i] = color(c1[0], c1[1], c1[2]);
    }
  }
  updateLedGrid();
  clearInput('input1');
}

function doButton() {
  var theText = getInput('input1');
  var tmp1 = theText + " ";
  var theItems = tmp1.split(" ");
  if (theItems[0] == 'save') {
    doSave();
    theText = '';
  }
  if (theItems[0] == 'draw') {
    drawCmds();
    theText = "";
    clearInput('input1');
  }
  if (theItems[0] == 'random') {
    doRandomPixels = 1 - doRandomPixels;
    theText = "";
    clearInput('input1');
  }
  if (theItems[0] == 'img') {
    imgTransfer(theItems[1] * 1);
    theText = "";
    clearInput('input1');
  }
  if (theText > "") {
    drawLedGrid(theText);
    clearInput('input1');
  }
}

function draw() {
  if (doDrawCmds == 1) {
    drawCmds();
  }
  if (doRandomPixels == 1) {
    if (frameCount % 2 == 0) {
      randomPixel();
    }
  }
  updateLedGrid();
}

function drawCmds() {
  for (i = 0; i < cmdsBuff.length; i++) {
    drawLedGrid(cmdsBuff[i]);
  }
}

function initDrawCmds() {
  cmdsBuff = new Array();
  cmdsBuff.push("fill w");
  cmdsBuff.push("lineh 0 0 16 r");
  cmdsBuff.push("linev 0 1 14 g");
  cmdsBuff.push("lineh 0 15 16 gb");
  cmdsBuff.push("linev 15 1 14 rg");
  cmdsBuff.push("line 7 7 0 5 r");
  cmdsBuff.push("line 7 7 1 5 r");
  cmdsBuff.push("line 7 7 2 5 r");
  cmdsBuff.push("line 7 7 3 5 r");
  cmdsBuff.push("line 7 7 4 5 r");
  cmdsBuff.push("line 7 7 5 5 r");
  cmdsBuff.push("line 7 7 6 5 r");
  cmdsBuff.push("line 7 7 7 5 r");
  cmdsBuff.push("set 7 7 b");
}

function updateLedGrid() {
  for (let y = 0; y < yMax; y++) {
    for (let x = 0; x < xMax; x++) {
      let xpos = x * sc;
      let ypos = y * sc;
      stroke(0);
      let index = (y * xMax) + x;
      fill(colr[index]);
      rect(xpos, ypos, sc - 1, sc - 1);
    }
  }
}

function setPixel(x, y, red, green, blue) {
  if (x < 0) {
    x = 0;
  }
  if (x > xMax) {
    x = xMax;
  }
  if (y < 0) {
    y = 0;
  }
  if (y > yMax) {
    y = yMax;
  }
  let index = (y * xMax) + x;
  colr[index] = color(red, green, blue);
}

function randomPixel() {
  let r1 = Math.floor(Math.random() * xMax);
  let r2 = Math.floor(Math.random() * yMax);
  let bl = Math.floor(Math.random() * 16);
  setPixel(r1, r2, color(r1 * 15, r2 * 15, bl * 15));
}

function getColrs(cmdStr) {
  var cmdItems = cmdStr.split(" ");
  var redColr = 255;
  var greenColr = 255;
  var blueColr = 255;
  redColr = parseInt(cmdItems[0]);
  greenColr = parseInt(cmdItems[1]);
  blueColr = parseInt(cmdItems[2]);
  if (cmdItems[0] == 'r') {
    redColr = 255;
    greenColr = 0;
    blueColr = 0;
  }
  if (cmdItems[0] == 'red') {
    redColr = 255;
    greenColr = 0;
    blueColr = 0;
  }
  if (cmdItems[0] == 'g') {
    redColr = 0;
    greenColr = 255;
    blueColr = 0;
  }
  if (cmdItems[0] == 'green') {
    redColr = 0;
    greenColr = 255;
    blueColr = 0;
  }
  if (cmdItems[0] == 'b') {
    redColr = 0;
    greenColr = 0;
    blueColr = 255;
  }
  if (cmdItems[0] == 'blue') {
    redColr = 0;
    greenColr = 0;
    blueColr = 255;
  }
  if (cmdItems[0] == 'rg') {
    redColr = 255;
    greenColr = 255;
    blueColr = 0;
  }
  if (cmdItems[0] == 'rb') {
    redColr = 255;
    greenColr = 0;
    blueColr = 255;
  }
  if (cmdItems[0] == 'gb') {
    redColr = 0;
    greenColr = 255;
    blueColr = 255;
  }
  if (cmdItems[0] == 'w') {
    redColr = 255;
    greenColr = 255;
    blueColr = 255;
  }
  if (cmdItems[0] == 'white') {
    redColr = 255;
    greenColr = 255;
    blueColr = 255;
  }
  return color(redColr, greenColr, blueColr);
}

function hline(cmdStr) {
  var cmdItems = cmdStr.split(" ");
  var redColr = 0;
  var greenColr = 0;
  var blueColr = 0;
  var x1 = parseInt(cmdItems[1]);
  var y1 = parseInt(cmdItems[2]);
  var len1 = parseInt(cmdItems[3]);
  var colr = getColrs(cmdItems[4] + " " + cmdItems[5] + " " + cmdItems[6] + " ");
  for (x = 0; x < len1; x++) {
    setPixel(x1 + x, y1, colr);
  }
}

function vline(cmdStr) {
  var cmdItems = cmdStr.split(" ");
  var x1 = parseInt(cmdItems[1]);
  var y1 = parseInt(cmdItems[2]);
  var len1 = parseInt(cmdItems[3]);
  var colr = getColrs(cmdItems[4] + " " + cmdItems[5] + " " + cmdItems[6] + " ");
  for (y = 0; y < len1; y++) {
    setPixel(x1, y1 + y, colr);
  }
}

function drawLine(cmdStr) {
  var cmdItems = cmdStr.split(" ");
  var x1 = parseInt(cmdItems[1]);
  var y1 = parseInt(cmdItems[2]);
  var d1 = parseInt(cmdItems[3]);
  var len1 = parseInt(cmdItems[4]);
  var colr = getColrs(cmdItems[5] + " " + cmdItems[6] + " " + cmdItems[7] + " ");
  var dx = 0;
  var dy = 0;
  if (d1 == 0) {
    dx = 0;
    dy = -1;
  }
  if (d1 == 1) {
    dx = 1;
    dy = -1;
  }
  if (d1 == 2) {
    dx = 1;
    dy = 0;
  }
  if (d1 == 3) {
    dx = 1;
    dy = 1;
  }
  if (d1 == 4) {
    dx = 0;
    dy = 1;
  }
  if (d1 == 5) {
    dx = -1;
    dy = 1;
  }
  if (d1 == 6) {
    dx = -1;
    dy = 0;
  }
  if (d1 == 7) {
    dx = -1;
    dy = -1;
  }
  for (l = 0; l < len1; l++) {
    setPixel(x1, y1, colr);
    x1 = x1 + dx;
    y1 = y1 + dy;
  }
}

function setLedGrid(cmdStr) {
  var cmdItems = cmdStr.split(" ");
  var x1 = parseInt(cmdItems[1]);
  var y1 = parseInt(cmdItems[2]);
  var colr = getColrs(cmdItems[3] + " " + cmdItems[4] + " " + cmdItems[5] + " ");
  setPixel(x1, y1, colr);
}

function fillLedGrid(cmdStr) {
  var cmdItems = cmdStr.split(" ");
  var theColr = getColrs(cmdItems[1] + " " + cmdItems[2] + " " + cmdItems[3] + " ");
  for (let y = 0; y < yMax; y++) {
    for (let x = 0; x < xMax; x++) {
      let xpos = x * sc;
      let ypos = y * sc;
      stroke(0);
      let index = y * xMax + x;
      colr[index] = theColr;
      fill(colr[index]);
      rect(xpos, ypos, sc - 1, sc - 1);
    }
  }
}

var str0 = '00f00f00f00ff00f00f00f0000f00f00f00fffffffffffff00f00f00f00ff00f00f00f0000f00f00f00ffffffffffffff00f00f00f00f00f00f00f00fffffffffffffffffffffffff00f00f00f00f00f00f00f00ffffffffffffffffffffffff';
smImg[0] = str0;

function drawLedGrid(cmdStr) {
  var cmdItems = cmdStr.split(" ");
  if (cmdItems[0] == 'draw') {

  }
  if (cmdItems[0] == 'lineh') {
    hline(cmdStr);
  }
  if (cmdItems[0] == 'linev') {
    vline(cmdStr);
  }
  if (cmdItems[0] == 'set') {
    setLedGrid(cmdStr);
  }
  if (cmdItems[0] == 'line') {
    drawLine(cmdStr);
  }
  if (cmdItems[0] == 'fill') {
    fillLedGrid(cmdStr);
  }
  if (cmdItems[0] == 'smdraw') {
    smDraw(cmdItems[1] * 1);
    clearInput('input1');
  }
}

function get8x8Pixel(x, y, str1) {
  var i = y * 8 + x;
  var str2 = str1.substr(i * 3, 3);
  var r = str2.substr(0, 1);
  var g = str2.substr(1, 1);
  var b = str2.substr(2, 1);
  r = parseInt(r, 16) * 16;
  g = parseInt(g, 16) * 16;
  b = parseInt(b, 16) * 16;
  var c = new Array(r, g, b);
  return (c);
}

function smDraw(theNum) {
  var theStr = smImg[theNum];
  for (x = 0; x < 8; x++) {
    for (y = 0; y < 8; y++) {
      var setRgb = get8x8Pixel(x, y, theStr);
      setRgb = setRgb[0] + ' ' + setRgb[1] + ' ' + setRgb[2];
      setLedGrid('set ' + x + ' ' + y + ' ' + setRgb);
    }
  }
}

initDrawCmds();

/*
	Functions doCommand() and doChat() are called from chatListener.js
*/

function doCommand(user, command, message, flags, extra) {
  if (command == 'led') {
    drawLedGrid(message);
    putVal('input1', message);
    doButton();
  }
}

function doChat(user, message, flags, self, extra) {}