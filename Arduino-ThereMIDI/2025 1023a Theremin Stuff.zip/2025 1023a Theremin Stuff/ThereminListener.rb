Sonic Pi Theremin Receiver
# This code listens for OSC messages from the Python GUI.

use_synth :sine # Use a sine wave for the classic theremin sound.

# This live_loop is a continuous process that syncs with OSC messages.
live_loop :theremin_receiver do
  # Wait for an OSC message with the address "/theremin/control".
  # The `sync` command blocks until a message is received.
  osc_data = sync "/osc*/theremin/control"
  
  # The OSC data is an array. Extract pitch and amplitude values.
  pitch = osc_data[0]
  amp = osc_data[1]
  
  # Play the note using the received values.
  play pitch, amp: amp, release: 0.1, attack: 0.01
  
  # Print the received values for debugging
  puts "Pitch: #{pitch}, Amplitude: #{amp}"
end
