live_loop :midi_piano do
  use_real_time
  note,velocity = sync "/midi:nano_rp2040_connect:1/note_on"
  synth :piano, note: note, amp: velocity / 127.0 * 2
end