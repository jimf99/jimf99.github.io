/*
Project: NeoPixel Organ + Continuous Theremin Hybrid
(C Major range A3–D5)
By ChatGPT & Jim F, Calgary AB
Date Created: Nov 8, 2025
Date Updated: Nov 19, 2025
*/

let port;
let reader;
let inputLine = "";
let v1 = 0, v2 = 0, v3 = 0, v4 = 0;

const NUM_NOTES = 12;
const colors = [
  [255,   0,   0],
  [255, 128,   0],
  [255, 255,   0],
  [  0, 255,   0],
  [  0, 255, 255],
  [  0,   0, 255],
  [128,   0, 255],
  [255,   0, 255],
  [255,  64, 128],
  [180, 255, 100],
  [255, 150, 200],
  [100, 255, 150]
];

const noteNames = ["A3","B3","C4","D4","E4","F4","G4","A4","B4","C5","D5","E5"];
const notes = [
  220.00, 246.94, 261.63, 293.66, 329.63, 349.23,
  392.00, 440.00, 493.88, 523.25, 587.33, 659.25
];

let oscs = [];
let playing = Array(NUM_NOTES).fill(false);
let buttonX = [];
let buttonY = [];

// Xylophone geometry
let buttonW = 40;
let buttonH = 100;
let buttonR = 20;

let idleBrightness = 0.45;
let hoverIndex = -1;

// Waveforms (Q/W/E/R controlled)
let currentWaveform = 'sine';

function setWaveformAll(type) {
  currentWaveform = type;
  for (let i = 0; i < oscs.length; i++) oscs[i].setType(type);
  thereminOsc.setType(type);
  console.log("Waveform set:", type);
}

// Theremin
let thereminActive = false;
let thereminOsc;
let thereminFreq = 0;
let thereminAmp = 0;

// Follow dot
let fx = 10;
let fy = 100;
let easing = 0.1;

function setup() {
  createCanvas(900, 300);
  noStroke();
  textAlign(CENTER, CENTER);
  textSize(16);
  rectMode(CENTER);

  // create oscillators
  for (let i = 0; i < NUM_NOTES; i++) {
    buttonX[i] = map(i, 0, NUM_NOTES - 1, 80, width - 80);
    buttonY[i] = height / 2;

    let osc = new p5.Oscillator(currentWaveform);
    osc.freq(notes[i]);
    osc.start();
    osc.amp(0);
    oscs.push(osc);
  }

  thereminOsc = new p5.Oscillator(currentWaveform);
  thereminOsc.start();
  thereminOsc.amp(0);

  let connectButton = createButton("Connect Serial");
  connectButton.mousePressed(connectSerial);
}

async function connectSerial() {
  try {
    port = await navigator.serial.requestPort();
    await port.open({ baudRate: 38400 });
    reader = port.readable
      .pipeThrough(new TextDecoderStream())
      .pipeThrough(new TransformStream({
        transform(chunk, controller) {
          inputLine += chunk;
          let lines = inputLine.split('\n');
          inputLine = lines.pop();
          lines.forEach(l => controller.enqueue(l.trim()));
        }
      }))
      .getReader();
    readSerialLoop();
  } catch (err) {
    console.error("Serial Connection Error:", err);
  }
}

async function readSerialLoop() {
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    if (value) processCSV(value);
  }
}

function processCSV(line) {
  let parts = line.split(',');
  if (parts.length === 4) {
    v1 = parseFloat(parts[0]);
    v2 = parseFloat(parts[1]);
    v3 = parseFloat(parts[2]);
    v4 = parseFloat(parts[3]);
  }
}

var lastNearest=0;

function draw() {
  drawGradientBackground();

  hoverIndex = -1;
  for (let i = 0; i < NUM_NOTES; i++) {
    if (dist(mouseX, mouseY, buttonX[i], buttonY[i]) < buttonR) hoverIndex = i;
  }

  // Draw bars
  for (let i = 0; i < NUM_NOTES; i++) {
    let brightness = idleBrightness;
    if (playing[i]) brightness = 1.0;
    else if (i === hoverIndex) brightness = 0.7;

    fill(
      colors[i][0] * brightness,
      colors[i][1] * brightness,
      colors[i][2] * brightness
    );

    rect(buttonX[i], buttonY[i], buttonW, buttonH, 8);

    fill(255);
    text(noteNames[i], buttonX[i], buttonY[i] - buttonH / 2 - 14);
    text(
      i < 9 ? (i + 1).toString() : (i === 9 ? '0' : i === 10 ? '-' : '='),
      buttonX[i],
      buttonY[i] + buttonH / 2 + 14
    );
  }

  // Theremin
  if (thereminActive) {
    let nearest = getNearestNoteIndex(mouseX, mouseY);
    playing[nearest]=1.0;
    lastNearest=nearest;
    fx += (buttonX[nearest] - fx) * easing;
    fy += (buttonY[nearest] - fy) * easing;

    let freq = notes[nearest];
    let vol = constrain(map(mouseY, height, 0, 0, 0.4), 0, 0.4);

    thereminFreq = freq;
    thereminAmp = vol;

    thereminOsc.freq(thereminFreq, 0.1);
    thereminOsc.amp(thereminAmp, 0.1);

    stroke(100, 200, 255, 120);
    line(mouseX, 0, mouseX, height);
    line(0, mouseY, width, mouseY);
    noStroke();
  } else {
    thereminOsc.amp(0, 0.2);
    fx += (mouseX - fx) * easing;
    fy += (mouseY - fy) * easing;
  }

  drawFollowDot();
}

function drawFollowDot() {
  let idx = getNearestNoteIndex(fx, fy);
  let c = colors[idx];
  fill(c[0], c[1], c[2]);
  ellipse(fx, fy, 30);
}

function getNearestNoteIndex(x, y) {
  let minDist = Infinity;
  let nearest = 0;
  for (let i = 0; i < NUM_NOTES; i++) {
    let d = dist(x, y, buttonX[i], buttonY[i]);
    if (d < minDist) {
      minDist = d;
      nearest = i;
    }
  }
  return nearest;
}

function mousePressed() {
  thereminActive = true;
}

function mouseReleased() {
  if(thereminActive==true) {
    thereminActive = false;
    for(i=0; i<=NUM_NOTES; i++) {
      playing[i]=0;
    }
  }
}

function keyPressed() {

  // --- Waveform switching (Q W E R ONLY) ---
  if (key === 'q' || key === 'Q') { setWaveformAll('sine'); return; }
  if (key === 'w' || key === 'W') { setWaveformAll('triangle'); return; }
  if (key === 'e' || key === 'E') { setWaveformAll('square'); return; }
  if (key === 'r' || key === 'R') { setWaveformAll('sawtooth'); return; }

  // --- Notes: numeric row ---
  let index = -1;
  if (key >= '1' && key <= '9') index = int(key) - 1;
  else if (key === '0') index = 9;
  else if (key === '-') index = 10;
  else if (key === '=') index = 11;
  
  if (index >= 0 && index < NUM_NOTES) {
      playing[index] ? stopNote(index) : playNote(index);
      playNote(index);
  }
}

function keyReleased() {
    for (let i = 0; i < NUM_NOTES; i++) stopNote(i);
}

function playNote(i) {
  if (!playing[i]) {
    playing[i] = true;
    oscs[i].amp(0.3, 0.05);
  }
}

function stopNote(i) {
  if (playing[i]) {
    playing[i] = false;
    oscs[i].amp(0, 0.3);
  }
}

function drawGradientBackground() {
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c1 = color(32, 32, 32);
    let c2 = color(128, 64, 255);
    let c = lerpColor(c1, c2, inter);
    stroke(c);
    line(0, y, width, y);
  }
}
