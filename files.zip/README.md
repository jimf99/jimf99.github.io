# Projects

## Artificial Intelligence
- [The Transformative Impact of AI and Generative AI on OSS and BSS in Telecommunications (Microsoft)](https://www.microsoft.com/en-us/industry/blog/telecommunications/2025/04/08/the-transformative-impact-of-ai-and-generative-ai-on-oss-and-bss-in-telecommunications/)
- [VoyageDallas - Anil Pantangi Interview](https://voyagedallas.com/interview/daily-inspiration-meet-anil-pantangi/)
- [Wonder Valley AI Data Centre Park (Google Search)](https://www.google.com/search?q=Wonder+Valley+AI+Data+Centre+Park)

## Arts
- [P5js Creative Coding (Beginners Tutorials)](https://www.youtube.com/watch?v=x1NxkEjfNtI&list=PL0beHPVMklwgMz4Z-mNp4_udo9mjBk7pn)

## Books / Authors

### Forrest M. Mims III
- [Look for books by Forrest M. Mims III](http://www.forrestmims.org/publications.html)
- [Make: Maverick Scientist: My Adventures as an Amateur Scientist (Google Search)](https://www.google.com/search?q=Make%3A+Maverick+Scientist%3A+My+Adventures+as+an+Amateur+Scientist)
- [Make: Maverick Scientist (Google Books)](https://www.google.ca/books/edition/Make_Maverick_Scientist/UUoCEQAAQBAJ?hl=en&gbpv=1&printsec=frontcover)
- [MakeZine.com - Forrest M. Mims III](https://makezine.com/author/forrest-m-mims-iii)

## Electronics & Circuits
- [Anas Kuzechie Projects (Blog)](https://akuzechie.blogspot.com/)
- [Anas Kuzechie YouTube](https://www.youtube.com/@AnasKuzechie/playlists)
- [Build Electronic Circuits - How Transistors Work](https://www.build-electronic-circuits.com/how-transistors-work/)
- [Build Electronic Circuits - Simple FM Transmitter](https://www.build-electronic-circuits.com/simple-fm-transmitter/)
- [How to Make Simple Amplifier Circuit Without IC (Instructables)](https://www.instructables.com/How-to-Make-Simple-Amplifier-Circuit-Without-IC/)
- [NTE1431 IC from Science Fair "160-In-One" Kit](https://www.youtube.com/watch?v=44a01ao-NuQ)
- [One Transistor Amp (Video 1)](https://youtu.be/Kk12KHVget4?si=PUNHuauTdFuU6RJi)
- [One Transistor Amp (Video 2)](https://youtu.be/QGInwQa_XEM?si=X-0im91_P1cmVopg)
- [Recreating NTE1431 IC From Science Fair "160-In-One" Kit](https://www.youtube.com/watch?v=44a01ao-NuQ)
- [Resinchem TM1638-MQTT](https://github.com/Resinchem/TM1638-MQTT/tree/main?tab=readme-ov-file)
- [TM1638 Overview](https://www.youtube.com/watch?v=KxfhVqne1Qs)
- [TM1638 Tutorial 1](https://www.youtube.com/watch?v=XhUMp5aGGqI)
- [Tom Igoe GitHub](https://github.com/tigoe)

## Electronics & Computers

### Arduino and Other Stuff
- [ADCTouch - Arduino Library](https://docs.arduino.cc/libraries/adctouch/)
- [ADCTouch (GitHub)](https://github.com/martin2250/ADCTouch)
- [Arduino](https://arduino.cc)
- [Arduino Built-in Examples](https://docs.arduino.cc/built-in-examples/)
- [Arduino LCD+Keypad Shield Games (GitHub)](https://github.com/dadecoza/arduino-lcd-keypad-shield-games)
- [Arduino Starter Kit Projects (Video Overview)](https://www.youtube.com/watch?v=0pESLpvpR00)
- [Arduino Theremin (ProjectHub)](https://projecthub.arduino.cc/tdelatorre/theremino-a-theremin-made-with-arduino-3e661f)
- [Arduino Theremin (Speaker and Tone, Wokwi)](https://wokwi.com/projects/394183708556652545)
- [Arduino Theremin (Wokwi MIDI Controller)](https://wokwi.com/projects/387845479260121089)
- [ELEGOO Arduino Super Starter Kit Tutorials](https://youtube.com/playlist?list=PLWdhcCYoOsiJE1DS7OhPfwrHrGlUED6Az)
- [ESP32 / BlueTooth Communications (Controller)](https://ai.thestempedia.com/docs/dabble-app/gamepad-module/)
- [FreeCodeCamp Arduino Tutorial Video](https://www.youtube.com/watch?v=DPqiIzK97K0)
- [MakeZine (Makers Magazine) Modern Day Internet Telegraph](https://makezine.com/projects/use-raspberry-pi-modern-day-telegraph/)
- [MIDI Controller (Wokwi)](https://wokwi.com/projects/387845479260121089)
- [Notes And Volts (Dave)](https://www.notesandvolts.com/)
- [Open Sound Control - Arduino Library](https://www.arduinolibraries.info/libraries/osc)
- [P5js TouchGUI Oscillator (Editor)](https://editor.p5js.org/jimf99/sketches/MdV3NQO_E)
- [P5js WebSerial Example (Editor)](https://editor.p5js.org/cacheflowe/sketches/F7GG8vuEy)
- [Shield Games Video](https://www.youtube.com/watch?v=ShZsyHIK6DI)
- [Solar Li-ion Battery Charger](https://www.youtube.com/watch?v=NaxtGdHR_6E)
- [Transistor Full Documentary](https://www.youtube.com/watch?v=U4XknGqr3Bo)
- [Wokwi Arduino Theremin (Speaker and Tone)](https://wokwi.com/projects/394183708556652545)

### James Lewis
- [BaldCorder tricorder (YouTube)](https://www.youtube.com/watch?v=ri2RpTgju-Y&t=766s)

### Other Tech
- [Audio from 20Hz to 20KHz](https://www.youtube.com/watch?v=qNf9nzvnd1k)
- [BASIC Programming](https://gotbasic.com/)
- [Forest M. Mims III (Interview Part 1)](https://www.youtube.com/watch?v=hUlzdFSNMkk)
- [Learned BASIC in 1979-1980 (SOL-20)](https://oldcomputers.net/sol-20.html)

## Electronics & Robotics
- [Bluepad32 Arduino Bluetooth Controller (GitHub)](https://github.com/ricardoquesada/bluepad32-arduino)
- [Danja TM1638lite (GitHub)](https://github.com/danja/TM1638lite)
- [TB6612FNG WokWi Project](https://wokwi.com/projects/410323062531374081)
- [TalkingElectronics (Colin Mitchell) Electronics Projects](https://www.talkingelectronics.com/projects/200TrCcts/200TrCcts.html)

## Library
- [Calgary Library Print](https://papercut.calgarylibrary.ca/user)

## Music

### MIDI, Synth, and Web Audio
- [Chrome Experiments - Music Lab](https://musiclab.chromeexperiments.com/Experiments)
- [Experiments with Google - Instrument Playground](https://experiments.withgoogle.com/instrument-playground)
- [Experiments with Google - Scan Sequencer](https://experiments.withgoogle.com/scan-sequencer)
- [MIDI Javascript (GitHub)](https://github.com/mudcube/MIDI.js)
- [MIDI.js Web MIDI](https://webmidijs.org/)
- [NeoTrellis DIY MIDI Controller](https://www.instructables.com/Neo-Chord-DIY-MIDI-Controller-for-Playing-Chords/)
- [Notes and Volts](https://www.notesandvolts.com/)
- [Open Theremin Kit](https://www.gaudi.ch/OpenTheremin/)
- [P5js Synth (Editor)](https://editor.p5js.org/JeanTim/sketches/3Pfg4_C6r)
- [P5JS Touch Events (Editor)](https://editor.p5js.org/bengrosser/sketches/GYPSrhPZe)
- [Theremix (Virtual Theremin App)](https://github.com/yeemachine/theremix)
- [Web MIDI](https://webmidijs.org/)

### Performance, Fun, and Learning
- [Chordify - Hey Soul Sister Chords](https://chordify.net/chords/train-songs/hey-soul-sister-chords)
- [Fun Karaoke](https://www.youtube.com/watch?v=sdQWAFtgIB4)
- [KaraFun Karaoke Playlists](https://www.youtube.com/@karafun/playlists)
- [Learn Ukelele with UkeBuddy](https://ukebuddy.com/)
- [People Carleton - Sound Basics](https://people.carleton.edu/~jellinge/m101s12/Pages/01/01SoundBasics.html)
- [Spotify - That Danner](https://open.spotify.com/artist/44yXARAgcTDepVyipsdigz)
- [Stingray 3 Hours Karaoke](https://www.youtube.com/watch?v=WiVuYFXiS14&list=PLD3E5F3350EEDE7F6&index=1)

### Theremin Projects
- [Arduino Midi Theremin (Musiconerd)](https://www.musiconerd.com/i-built-a-midi-theremin/)
- [Arduino Midi Theremin (Video)](https://www.youtube.com/watch?v=CWPtxGrBlU8)
- [DIY BASS Guitar MIDI Controller (Advanced)](https://www.youtube.com/watch?v=0U1bAcWDPBI)
- [DIY Ukelele MIDI Controller (Basic)](https://www.youtube.com/watch?v=tW2iFr9qjI0)
- [DIY Wireless MIDI Controllers](https://www.youtube.com/watch?v=zFWH0xxBsnQ)
- [How to make a Theremin (DIY Project)](https://www.youtube.com/watch?v=oRhO0MJIl58)
- [Theremin World](http://thereminworld.com/)

### Other
- [FGpwXq9Kbhk (YouTube)](https://www.youtube.com/watch?v=FGpwXq9Kbhk)
- [kVpv8-5XWOI (YouTube)](https://www.youtube.com/watch?v=kVpv8-5XWOI)

## Projects (Personal)
- [9cansPoC](https://jimf99.github.io/9cansPoC.html)
- [9CansPoC_1](https://jimf99.github.io/9CansPoC_1/index.html)
- [racer-1a](https://jimf99.github.io/racer-1a/index.html)
- [racer-1b](https://jimf99.github.io/racer-1b/index.html)

### S.T.R.E.A.M.
- [S.T.R.E.A.M. Home](https://jimf99.github.io/stream/index.html)

#### Stream => Electronics + Circuits
- [How Transistors Work](https://www.build-electronic-circuits.com/how-transistors-work/)
- [One Transistor Amp (Video 1)](https://youtu.be/Kk12KHVget4?si=PUNHuauTdFuU6RJi)
- [One Transistor Amp (Video 2)](https://youtu.be/QGInwQa_XEM?si=X-0im91_P1cmVopg)
- [Simple Amplifier Circuit Without IC (Instructables)](https://www.instructables.com/How-to-Make-Simple-Amplifier-Circuit-Without-IC/)
- [Simple FM Transmitter](https://www.build-electronic-circuits.com/simple-fm-transmitter/)

#### Stream => Electronics + Computers
- [TouchGUI Oscillator (p5js)](https://editor.p5js.org/jimf99/sketches/MdV3NQO_E)
- [WebSerial Example (p5js)](https://editor.p5js.org/cacheflowe/sketches/F7GG8vuEy)
- [hDv2gmcI5 (p5js)](https://editor.p5js.org/jimf99/sketches/hDv2gmcI5)
- [kenzo WebSerial Sketch (p5js)](https://editor.p5js.org/kenzo/sketches/Bk6Xa7Kgg)

#### Stream => Electronics + Robotics
- [Bluepad32 Arduino Bluetooth Controller](https://github.com/ricardoquesada/bluepad32-arduino)
- [TB6612FNG WokWi Project](https://wokwi.com/projects/410323062531374081)
- [TM1638lite (GitHub)](https://github.com/danja/TM1638lite)

#### Stream => Music
- [JeanTim Synth (p5js)](https://editor.p5js.org/JeanTim/sketches/3Pfg4_C6r)
- [P5JS Touch Events (Editor)](https://editor.p5js.org/bengrosser/sketches/GYPSrhPZe)

#### Stream => Respect + Friendships
- [Respect](https://jimf99.github.io/stream/respect)
- [Agape Language Centre](https://agapelanguagecentre.com/)

## Temp Notes
- [Animation and Variables (p5js)](https://p5js.org/examples/animation-and-variables-mobile-device-movement/)
- [OpenProcessing Sketch 1200514](https://openprocessing.org/sketch/1200514)
- [OpenProcessing Sketch 422944](https://openprocessing.org/sketch/422944)
- [XiDUFJO5p (p5js)](https://editor.p5js.org/jimf99/sketches/XiDUFJO5p)
- [MdV3NQO_E (p5js)](https://editor.p5js.org/jimf99/sketches/MdV3NQO_E)
- [hDv2gmcI5 (p5js)](https://editor.p5js.org/jimf99/sketches/hDv2gmcI5)

## Utils
- [apitemplate.io - Markdown to PDF Tools](https://apitemplate.io/pdf-tools/convert-markdown-to-pdf/)

## Culture - Beliefs
- [Christianity (Wikipedia)](https://en.wikipedia.org/wiki/Christianity)
- [Islam (Wikipedia)](https://en.wikipedia.org/wiki/Islam)
- [Islam / Quran (English, PDF)](https://www.clearquran.com/downloads/quran-english-translation-clearquran-edition-allah.pdf)
- [Judaism (Wikipedia)](https://en.wikipedia.org/wiki/Judaism)