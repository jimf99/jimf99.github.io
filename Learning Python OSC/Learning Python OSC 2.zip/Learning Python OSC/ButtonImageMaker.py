from PIL import Image, ImageDraw, ImageFont
import os

def create_button_image(text, filename, size=(60, 60), bg_color='lightblue', text_color='black'):
    """
    Generates a round-ish button image with text and saves it as a PNG file.
    """
    # Create a new image with a transparent background (RGBA mode)
    img = Image.new('RGBA', size, color=(0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw a rounded rectangle background
    # Coordinates are (x1, y1, x2, y2)
    draw.rounded_rectangle((2, 2, size[0]-2, size[1]-2), fill=bg_color, radius=10)

    # Define font (adjust path as necessary for your OS)
    try:
        # Common font name, adjust size as needed
        font = ImageFont.truetype("arial.ttf", 24) 
    except IOError:
        # Fallback to a default font if 'arial.ttf' is not found
        font = ImageFont.load_default() 
        print("Using default font, consider installing 'arial.ttf' for better appearance.")
    
    # Calculate text position to center it
    bbox = draw.textbbox((0, 0), text, font=font)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    # Center the text
    x = (size[0] - text_width) / 2
    y = (size[1] - text_height) / 2
    
    draw.text((x, y), text, font=font, fill=text_color)
    
    # Save the image as PNG
    img.save(filename, "PNG")
    print(f"Created {filename}")

# --- Generate all required images ---

# Image settings
BTN_SIZE = (60, 60)
NUM_COLOR = 'white'
OP_COLOR = 'orange'
EQ_COLOR = 'green'
C_COLOR = 'red'

# Numbers 0-9 and decimal point
for i in range(10):
    create_button_image(str(i), f'img_{i}.png', BTN_SIZE, NUM_COLOR)

create_button_image('.', 'img_dot.png', BTN_SIZE, NUM_COLOR)

# Operators
create_button_image('+', 'img_add.png', BTN_SIZE, OP_COLOR)
create_button_image('-', 'img_sub.png', BTN_SIZE, OP_COLOR)
create_button_image('*', 'img_mul.png', BTN_SIZE, OP_COLOR)
create_button_image('/', 'img_div.png', BTN_SIZE, OP_COLOR)

# Equals and Clear
create_button_image('=', 'img_equal.png', BTN_SIZE, EQ_COLOR)
create_button_image('C', 'img_C.png', BTN_SIZE, C_COLOR)

print("\nAll calculator button images have been generated.")
