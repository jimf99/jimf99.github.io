import tkinter as tk

# Create main window
root = tk.Tk()
root.title("Large Font Display")

# Set the dimensions of the window
root.geometry("400x200")

# Create a Text widget
display = tk.Text(root, height=4, width=20, font=("Helvetica", 24), wrap='word')
display.pack(pady=20)

# Insert sample text into the Text widget
sample_text = "Line 1\nLine 2\nLine 3\nLine 4"
display.insert(tk.END, sample_text)

# Disable editing
display.config(state=tk.DISABLED)

# Run the application
root.mainloop()
