import tkinter as tk

def button_click(value):
    """Function to handle button clicks (e.g., append to an entry box)"""
    # Example action: print the value to the console
    print(f"Button '{value}' clicked")

# --- Main application setup ---
root = tk.Tk()
root.title("Keypad")
root.configure(bg='gray')

# Frame to hold the buttons
keypad_frame = tk.Frame(root, bg='gray')
keypad_frame.pack(padx=10, pady=10)

# Keypad button layout
buttons = [
    '7', '8', '9',
    '4', '5', '6',
    '1', '2', '3',
    'C', '0', '='
]

# --- Button Styling Options ---
button_style = {
    'width': 2,          # Width in text units
    'height': 2,         # Height in text units
    'bg': '#0000FF',     # Light gray background
    'fg': '#0000ff',       # Black text color
    'font': ('Arial', 14, 'bold'),
    'relief': tk.RAISED, # Raised border effect
    'bd': 2,             # Border width
    'activebackground': '#e0e0e0', # Color when pressed/hovered
    'activeforeground': 'black',
}

# --- Create buttons using a loop and grid manager ---
row_val = 0
col_val = 0

for button_text in buttons:
    # Use lambda to pass the button text to the function when clicked
    command = lambda key=button_text: button_click(key)
    
    btn = tk.Button(keypad_frame, text=button_text, command=command, **button_style)
    btn.grid(row=row_val, column=col_val, padx=5, pady=5, sticky="nsew") # sticky="nsew" makes buttons expand to fill cell

    col_val += 1
    if col_val > 2:
        col_val = 0
        row_val += 1

# Configure the grid to ensure buttons expand uniformly with the window
for i in range(4): # 4 rows
    keypad_frame.rowconfigure(i, weight=1)
for i in range(3): # 3 columns
    keypad_frame.columnconfigure(i, weight=1)

root.mainloop()
