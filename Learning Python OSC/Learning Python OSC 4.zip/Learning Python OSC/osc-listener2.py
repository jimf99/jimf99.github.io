import wx
from pythonosc import dispatcher
from pythonosc import osc_server
from pythonosc import udp_client

# Initialize cmd_msg
cmd_msg = ""

# Constants for OSC configuration
OSC_IP = "127.0.0.1"  # Target IP for OSC
OSC_PORT = 4560       # OSC port

# Constants for Serial configuration
SERIAL_PORT = '/dev/cu.usbserial-0001'  # Change this to your USB serial port
BAUD_RATE = 9600                       # Standard baud rate

# Set up the OSC client
osc_client = udp_client.SimpleUDPClient(OSC_IP, OSC_PORT)

osc_address="/key/"


# Function to evaluate OSC messages
def key_listener(unused_addr, value):
    global cmd_msg
    if value == "#":
        # Try to evaluate cmd_msg if it looks like a calculation
        try:
            # Evaluate and print the result if it's a valid expression
            result=""
            try:
              result = eval(cmd_msg)
            except Exception as e:
                result=""
                cmd_msg=""
            result = "=" + str(result)
            if(result=="="):
                result=""
            print(f"{cmd_msg} {result}")  # Display result
            osc_client.send_message(osc_address, cmd_msg+result)
        except Exception as e:
            print(f"Error evaluating expression '{cmd_msg}': {e}")
        cmd_msg = ""  # Reset cmd_msg
    else:
        cmd_msg += str(value)  # Append received value to cmd_msg
    update_display(cmd_msg)  # Update the display with the latest message

# Function to update the wxPython window
def update_display(message):
    if wx.GetApp():
        wx.CallAfter(frame.update_message, message)

# wxPython frame class
class MyFrame(wx.Frame):
    def __init__(self, *args, **kwargs):
        super(MyFrame, self).__init__(*args, **kwargs)
        self.panel = wx.Panel(self)
        self.text = wx.StaticText(self.panel, label="", style=wx.ALIGN_CENTER)
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.text, 0, wx.ALL | wx.CENTER, 5)
        self.panel.SetSizer(self.sizer)
        self.SetTitle("OSC Message Display")
        self.SetSize((300, 100))

    def update_message(self, message):
        self.text.SetLabel(message)

if __name__ == "__main__":
    # Set up the dispatcher for OSC
    disp = dispatcher.Dispatcher()
    disp.map("/key/", key_listener)

    # Create a wxPython application
    app = wx.App(False)
    frame = MyFrame(None)
    frame.Show()

    # Create and start the OSC server in a separate thread
    server = osc_server.BlockingOSCUDPServer(("127.0.0.1", 4560), disp)
    print("Listening on UDP port 4560...")
    
    # Start the OSC server on a separate thread
    import threading
    server_thread = threading.Thread(target=server.serve_forever)
    server_thread.start()

    # Start the wxPython event loop
    app.MainLoop()
