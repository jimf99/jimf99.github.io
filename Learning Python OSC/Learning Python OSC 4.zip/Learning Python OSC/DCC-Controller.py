import tkinter as tk
from tkinter import ttk

class DCCThrottleController:
    def __init__(self, root):
        self.root = root
        self.root.title("DCC Throttle Controller")

        # Train address
        self.train_address = tk.StringVar(value="1")
        
        # Speed variable
        self.speed = tk.DoubleVar(value=0)

        # Direction variable
        self.direction = tk.StringVar(value="Forward")

        # Calculator input
        self.calculator_input = tk.StringVar()

        # Light and bell state
        self.lights_on = False
        self.bell_on = False
        
        self.create_widgets()

    def create_widgets(self):
        # Train Address Label and Entry
        ttk.Label(self.root, text="Train Address:").grid(column=0, row=0, padx=10, pady=10)
        ttk.Entry(self.root, textvariable=self.train_address).grid(column=1, row=0, padx=10, pady=10)

        # Speed Control
        ttk.Label(self.root, text="Speed:").grid(column=0, row=1, padx=10)
        speed_scale = ttk.Scale(self.root, from_=0, to=100, variable=self.speed, orient="horizontal", command=self.update_speed)
        speed_scale.grid(column=1, row=1, padx=10)

        # Direction Buttons
        ttk.Button(self.root, text="Forward", command=lambda: self.do_command("forward")).grid(column=0, row=2, padx=10, pady=10)
        ttk.Button(self.root, text="Reverse", command=lambda: self.do_command("reverse")).grid(column=1, row=2, padx=10, pady=10)

        # Momentary Horn Button
        ttk.Button(self.root, text="Horn", command=lambda: self.do_command("horn")).grid(column=0, row=3, padx=10, pady=10)

        # Toggle Lights Button
        ttk.Button(self.root, text="Toggle Lights", command=lambda: self.do_command("toggle_lights")).grid(column=1, row=3, padx=10, pady=10)

        # Toggle Bell Button
        ttk.Button(self.root, text="Toggle Bell", command=lambda: self.do_command("toggle_bell")).grid(column=0, row=4, padx=10, pady=10)

        # Status Label
        self.status_label = ttk.Label(self.root, text="Status: Idle")
        self.status_label.grid(column=0, row=5, columnspan=2, pady=10)

        # Calculator Input Field
        ttk.Entry(self.root, textvariable=self.calculator_input).grid(column=0, row=6, columnspan=2, padx=10, pady=10)

        # Calculator Buttons A-G
        buttons = ['1','2','3','A',
                   '4','5','6','B',
                   '7','8','9','C',
                   '*','0','#','D',
                   'E', 'F', '.', '-'
                   ]
        for i, label in enumerate(buttons):
            ttk.Button(self.root, text=label, command=lambda l=label: self.add_to_calculator(l)).grid(column=i % 4, row=7 + (i // 4), padx=5, pady=5)

    def update_speed(self, value):
        speed = float(value)
        self.status_label.configure(text=f"Status: Speed set to {speed:.1f} (Direction: {self.direction.get()})")

    def do_command(self, command):
        if command == "forward":
            self.direction.set("Forward")
            self.status_label.configure(text=f"Status: Moving Forward at {self.speed.get():.1f}")
        elif command == "reverse":
            self.direction.set("Reverse")
            self.status_label.configure(text=f"Status: Moving Reverse at {self.speed.get():.1f}")
        elif command == "horn":
            self.status_label.configure(text="Status: Horn activated!")
        elif command == "toggle_lights":
            self.lights_on = not self.lights_on
            status = "on" if self.lights_on else "off"
            self.status_label.configure(text=f"Status: Lights turned {status}")
        elif command == "toggle_bell":
            self.bell_on = not self.bell_on
            status = "on" if self.bell_on else "off"
            self.status_label.configure(text=f"Status: Bell turned {status}")

    def add_to_calculator(self, value):
        # Append button value to calculator input
        current_value = self.calculator_input.get()
        self.calculator_input.set(current_value + value)

if __name__ == "__main__":
    root = tk.Tk()
    app = DCCThrottleController(root)
