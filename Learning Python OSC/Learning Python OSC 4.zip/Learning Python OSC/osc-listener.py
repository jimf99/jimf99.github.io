from pythonosc import dispatcher
from pythonosc import osc_server

# Initialize cmd_msg
cmd_msg = ""

def key_listener(unused_addr, value):
    global cmd_msg
    if value == "#":
        # Try to evaluate cmd_msg if it looks like a calculation
        try:
            # Evaluate and print the result if it's a valid expression
            result = eval(cmd_msg)
            print(f"{cmd_msg} = {result}")  # Display result
        except Exception as e:
            print(f"Error evaluating expression '{cmd_msg}': {e}")
        cmd_msg = ""  # Reset cmd_msg
    else:
        cmd_msg += str(value)  # Append received value to cmd_msg

if __name__ == "__main__":
    # Set up the dispatcher for OSC
    disp = dispatcher.Dispatcher()
    disp.map("/key/", key_listener)

    # Create and start the OSC server
    server = osc_server.BlockingOSCUDPServer(("127.0.0.1", 4560), disp)
    print("Listening on UDP port 4560...")
    server.serve_forever()
